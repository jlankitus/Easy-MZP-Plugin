#directoryCopies script by Ryan Amos

import os  
import shutil
from os import path
from distutils.dir_util import copy_tree

sourceList = []
destinationList = []
countVar = 0

#Please note that this script is currently setup to work for 3DS Max 2020. Update for your version if necessary.
versionSupport = ["2020","2019","2018","2017","2016","2015"]
#versionSupport index is 0,1,2,3,4,5; pick the index value matching your version.
versionIs = versionSupport[0]
print("Version is:"), versionIs

localDir = path.expandvars(r'%LOCALAPPDATA%')

sourceList.append (localDir + "/Autodesk/3dsMax/" + versionIs + " - 64bit/ENU/temp/Remesher/datasets/")
destinationList.append (localDir +"/Autodesk/3dsMax/" + versionIs + " - 64bit/ENU/scripts/Remesher/datasets/")
countVar +=1

sourceList.append (localDir + "/Autodesk/3dsMax/" + versionIs + " - 64bit/ENU/temp/Cleaner/cleaner_v25/")
destinationList.append (localDir + "/Autodesk/3dsMax/" + versionIs + " - 64bit/ENU/scripts/Cleaner/cleaner_v25/")
countVar +=1

sourceList.append (localDir + "/Autodesk/3dsMax/" + versionIs + " - 64bit/ENU/temp/InstanceTool/Icons/")
destinationList.append (localDir + "/Autodesk/3dsMax/" + versionIs + " - 64bit/ENU/usericons/")
countVar +=1

sourceList.append (localDir + "/Autodesk/3dsMax/" + versionIs + " - 64bit/ENU/temp/CustomScripts/Icons/")
destinationList.append (localDir + "/Autodesk/3dsMax/" + versionIs + " - 64bit/ENU/usericons/")
countVar +=1

sourceList.append (localDir + "/Autodesk/3dsMax/" + versionIs + " - 64bit/ENU/temp/Test/")
destinationList.append (localDir + "/Autodesk/3dsMax/" + versionIs + " - 64bit/ENU/scripts/Testing/")
countVar +=1

i = 0
while i < countVar:
    #print (i) - This can be used to test that the while loop is active and making it through each pass of the lists above.
    try:
        copy_tree(sourceList[i], destinationList[i])
        #Except - Pass: This quelches warnings about copying directories that already exist in the target location.
        #Comment out the following two lines when adding in directories as thrown errors will help you debug.
        #Revert once your copies function correctly.
    except OSError:
        pass
    i += 1
else:
    print ("Directories processed:"), countVar
    print("Python -> Maxscript")