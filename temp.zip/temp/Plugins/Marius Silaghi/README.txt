Installation
1) Close 3ds Max.
2) Copy the files to the folder that matches your 3ds Max version to your "plugins" folder in your 3ds Max instalation directory(C:\Program Files\Autodesk\3ds Max xxxx\plugins)
3) Open 3ds Max and look in the modifier list.


Updating
Do the same steps like the on the Instalation but replace the existing "Deformation Cleaner.dlm" file


Uninstallation
Delete the "Deformation Cleaner.dlm" file from the plugins folder in the 3ds Max install directory.