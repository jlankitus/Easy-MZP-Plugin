Put the file in 3dsmax/scripts/startup folder.
Restart 3dsmax.
Go in the create panel, helpers, find the KinematicLAB category.
You�ll find a new helper called NodeLIST, press the button and click and drag in your scene to create the helper.