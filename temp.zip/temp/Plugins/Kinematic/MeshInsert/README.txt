Place your MeshInsert_1.lic file in the root of your #scripts directory. You'll have received this directly from Kinematic Labs/Hocus Pocus.

Place MSE files in your #scripts directory. (C:\Program Files\Autodesk\3ds Max\<Version>\scripts\)

Place 'MeshInsert_HELP.chm' in C:\Program Files\Autodesk\<Version>\help.

Place MSE files and the JPG file in your #scripts directory.

Place Icons in C:\Program Files\Autodesk\3ds Max 2020\UI_ln\Icons.

Place K_Functions.mse in your #startupScripts directory. (C:\Program Files\Autodesk\3ds Max\<Version>\scripts\startup\)

You'll find the scripts available under the Category: Orion Scripts in the 'Customize UI' menu.

Export Insert_ASSETS_2013.rar to a location of your choosing.