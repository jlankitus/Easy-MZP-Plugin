import MaxPlus, pymxs
from pymxs import runtime as rt

print "python script called!"